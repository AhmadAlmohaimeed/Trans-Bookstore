
class Vehicle {
    constructor(name, manufacturer, ID) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.ID = ID;
    }
}

class Car extends Vehicle {
    constructor(name, manufacturer, ID, carType) {
        super(name, manufacturer, ID);
        this.carType = carType; // gas or electric
    }
}

class Airplane extends Vehicle {
    constructor(name, manufacturer, ID, planeType) {
        super(name, manufacturer, ID);
        this.planeType = planeType;
    }
}

class Employee {
    constructor(name, ID, dob) {
        this.name = name;
        this.ID = ID;
        this.dob = dob;
    }
}

class Driver extends Employee {
    constructor(name, ID, dob, licenseID) {
        super(name, ID, dob);
        this.licenseID = licenseID;
    }
}

class Pilot extends Employee {
    constructor(name, ID, dob, licenseID) {
        super(name, ID, dob);
        this.licenseID = licenseID;
    }
}

class Reservation {
    constructor(reservationDate, employeeId, vehiclesId, reservationID) {
        this.reservationDate = reservationDate;
        this.employeeId = employeeId;
        this.vehiclesId = vehiclesId;
        this.reservationID = reservationID;
    }
}

const car1 = new Car("camry", "toyota", 1, "Gas");
const car2 = new Car("Model 3", "Tesla", 2, "Electric");
const car3 = new Car("xtrail", "nissan", 3, "Gas");

const airplane1 = new Airplane("A320", "Airbus", 4, "Passenger plane");
const airplane2 = new Airplane("747", "Boeing", 5, "Passenger plane");

const driver1 = new Driver("ahmad", 1, new Date(2000, 7, 11), "D127486");
const driver2 = new Driver("mohammed", 2, new Date(1999, 2, 22), "D789312");

const pilot1 = new Pilot("hamad", 3, new Date(1970, 3, 18), "P395678");
const pilot2 = new Pilot("khalid", 4, new Date(1985, 5, 24), "P401294");