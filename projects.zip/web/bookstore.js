

let books = [[1,'computer','ahmad',80.0, 13],
            [2,'business','ali',59.9, 22],
            [3,'mathematics','abdullah',50.0, 5],
            [4,'physics','mohammed',45.0, 12],
            [5,'programming','khaled',39.9, 9]];

let book_inde;
 function find_book(id, title, author){
     for (let i = 0; i < books.length; i++) {
         for (let j = 0; j < books[i].length; j++) {
             if (books[i][j] == id || books[i][j] == title || books[i][j] == author) {
                 book_inde = i
                 return books[i]
                }
            }
        }
    }
            
 function sell_book(title ,quantity, wallet){
    let book = find_book(title)
    // if the book doesn't exist
        if (book == undefined) {
            return `Sorry we don't have this book (${title})`
      } 
      else{
    let final_price = book[3] * quantity
        if (quantity <= book[book.length - 1] && final_price <= wallet) {
           book[book.length - 1] -= quantity
           books[book_inde] = book
           console.log(books);
           return `you have to pay $${final_price} the one book price is $${book[3]}`
        }else if(final_price > wallet){
             return `Sorry you don't have enough money the final price is $${final_price}`
         }
        }
 }
 console.log(sell_book('physics', 3, 190))